﻿using System;
using LuaInterface;

public class fogs_proto_msg_TaskTypeWrap
{
	static LuaMethod[] enums = new LuaMethod[]
	{
		new LuaMethod("FESTIVAL", GetFESTIVAL),
		new LuaMethod("MAIN", GetMAIN),
		new LuaMethod("DAILY", GetDAILY),
		new LuaMethod("SIGN", GetSIGN),
		new LuaMethod("OHTER", GetOHTER),
		new LuaMethod("IntToEnum", IntToEnum),
	};

	public static void Register(IntPtr L)
	{
		LuaScriptMgr.RegisterLib(L, "fogs.proto.msg.TaskType", typeof(fogs.proto.msg.TaskType), enums);
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int GetFESTIVAL(IntPtr L)
	{
		LuaScriptMgr.Push(L, fogs.proto.msg.TaskType.FESTIVAL);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int GetMAIN(IntPtr L)
	{
		LuaScriptMgr.Push(L, fogs.proto.msg.TaskType.MAIN);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int GetDAILY(IntPtr L)
	{
		LuaScriptMgr.Push(L, fogs.proto.msg.TaskType.DAILY);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int GetSIGN(IntPtr L)
	{
		LuaScriptMgr.Push(L, fogs.proto.msg.TaskType.SIGN);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int GetOHTER(IntPtr L)
	{
		LuaScriptMgr.Push(L, fogs.proto.msg.TaskType.OHTER);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int IntToEnum(IntPtr L)
	{
		int arg0 = (int)LuaDLL.lua_tonumber(L, 1);
		fogs.proto.msg.TaskType o = (fogs.proto.msg.TaskType)arg0;
		LuaScriptMgr.Push(L, o);
		return 1;
	}
}

