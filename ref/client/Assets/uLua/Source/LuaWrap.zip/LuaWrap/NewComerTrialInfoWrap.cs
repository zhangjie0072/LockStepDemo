﻿using System;
using LuaInterface;

public class NewComerTrialInfoWrap
{
	public static void Register(IntPtr L)
	{
		LuaMethod[] regs = new LuaMethod[]
		{
			new LuaMethod("New", _CreateNewComerTrialInfo),
			new LuaMethod("GetClassType", GetClassType),
		};

		LuaField[] fields = new LuaField[]
		{
			new LuaField("info", get_info, null),
			new LuaField("shoot_times", get_shoot_times, set_shoot_times),
			new LuaField("challenge_times", get_challenge_times, set_challenge_times),
			new LuaField("bullfight_times", get_bullfight_times, set_bullfight_times),
			new LuaField("qualifying_times", get_qualifying_times, set_qualifying_times),
			new LuaField("ladder_times", get_ladder_times, set_ladder_times),
			new LuaField("diamond_use", get_diamond_use, set_diamond_use),
			new LuaField("total_score", get_total_score, set_total_score),
			new LuaField("awards_flag", get_awards_flag, set_awards_flag),
		};

		LuaScriptMgr.RegisterLib(L, "NewComerTrialInfo", typeof(fogs.proto.msg.NewComerTrialInfo), regs, fields, typeof(object));
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int _CreateNewComerTrialInfo(IntPtr L)
	{
		int count = LuaDLL.lua_gettop(L);

		if (count == 0)
		{
			fogs.proto.msg.NewComerTrialInfo obj = new fogs.proto.msg.NewComerTrialInfo();
			LuaScriptMgr.PushObject(L, obj);
			return 1;
		}
		else
		{
			LuaDLL.luaL_error(L, "invalid arguments to method: fogs.proto.msg.NewComerTrialInfo.New");
		}

		return 0;
	}

	static Type classType = typeof(fogs.proto.msg.NewComerTrialInfo);

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int GetClassType(IntPtr L)
	{
		LuaScriptMgr.Push(L, classType);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int get_info(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name info");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index info on a nil value");
			}
		}

		LuaScriptMgr.PushObject(L, obj.info);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int get_shoot_times(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name shoot_times");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index shoot_times on a nil value");
			}
		}

		LuaScriptMgr.Push(L, obj.shoot_times);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int get_challenge_times(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name challenge_times");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index challenge_times on a nil value");
			}
		}

		LuaScriptMgr.Push(L, obj.challenge_times);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int get_bullfight_times(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name bullfight_times");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index bullfight_times on a nil value");
			}
		}

		LuaScriptMgr.Push(L, obj.bullfight_times);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int get_qualifying_times(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name qualifying_times");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index qualifying_times on a nil value");
			}
		}

		LuaScriptMgr.Push(L, obj.qualifying_times);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int get_ladder_times(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name ladder_times");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index ladder_times on a nil value");
			}
		}

		LuaScriptMgr.Push(L, obj.ladder_times);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int get_diamond_use(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name diamond_use");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index diamond_use on a nil value");
			}
		}

		LuaScriptMgr.Push(L, obj.diamond_use);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int get_total_score(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name total_score");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index total_score on a nil value");
			}
		}

		LuaScriptMgr.Push(L, obj.total_score);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int get_awards_flag(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name awards_flag");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index awards_flag on a nil value");
			}
		}

		LuaScriptMgr.Push(L, obj.awards_flag);
		return 1;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int set_shoot_times(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name shoot_times");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index shoot_times on a nil value");
			}
		}

		obj.shoot_times = (uint)LuaScriptMgr.GetNumber(L, 3);
		return 0;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int set_challenge_times(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name challenge_times");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index challenge_times on a nil value");
			}
		}

		obj.challenge_times = (uint)LuaScriptMgr.GetNumber(L, 3);
		return 0;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int set_bullfight_times(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name bullfight_times");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index bullfight_times on a nil value");
			}
		}

		obj.bullfight_times = (uint)LuaScriptMgr.GetNumber(L, 3);
		return 0;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int set_qualifying_times(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name qualifying_times");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index qualifying_times on a nil value");
			}
		}

		obj.qualifying_times = (uint)LuaScriptMgr.GetNumber(L, 3);
		return 0;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int set_ladder_times(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name ladder_times");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index ladder_times on a nil value");
			}
		}

		obj.ladder_times = (uint)LuaScriptMgr.GetNumber(L, 3);
		return 0;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int set_diamond_use(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name diamond_use");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index diamond_use on a nil value");
			}
		}

		obj.diamond_use = (uint)LuaScriptMgr.GetNumber(L, 3);
		return 0;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int set_total_score(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name total_score");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index total_score on a nil value");
			}
		}

		obj.total_score = (uint)LuaScriptMgr.GetNumber(L, 3);
		return 0;
	}

	[MonoPInvokeCallbackAttribute(typeof(LuaCSFunction))]
	static int set_awards_flag(IntPtr L)
	{
		object o = LuaScriptMgr.GetLuaObject(L, 1);
		fogs.proto.msg.NewComerTrialInfo obj = (fogs.proto.msg.NewComerTrialInfo)o;

		if (obj == null)
		{
			LuaTypes types = LuaDLL.lua_type(L, 1);

			if (types == LuaTypes.LUA_TTABLE)
			{
				LuaDLL.luaL_error(L, "unknown member name awards_flag");
			}
			else
			{
				LuaDLL.luaL_error(L, "attempt to index awards_flag on a nil value");
			}
		}

		obj.awards_flag = (uint)LuaScriptMgr.GetNumber(L, 3);
		return 0;
	}
}

